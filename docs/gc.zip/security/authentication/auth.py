from connections.cache import cache
from security.authentication.const import *


def verify_token(profile_id: int, token: str):
    res = cache.set(name=f'tkn:{profile_id}',
                    value=f'{token}',
                    ex=TOKEN_TIMEOUT,
                    nx=True
                    )
    return res
