# global
import uvicorn
from fastapi import FastAPI, Depends, Header
from security.authentication import auth

# routes
import common.route
import role.route
import snowflake.route

# create server
gc = FastAPI(
    swagger_ui_parameters={"defaultModelsExpandDepth": -1}
    # dependencies=[Depends(auth.verify_token(12345, 'token'))]
    # Depends(ratelimit)
)

# include routes
gc.include_router(common.route.router)
gc.include_router(role.route.router)
gc.include_router(snowflake.route.router)

# start listening
if __name__ == '__main__':
    uvicorn.run(gc, port=5127, host='0.0.0.0')
