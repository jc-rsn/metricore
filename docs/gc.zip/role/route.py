from typing import List
from fastapi import APIRouter
from role import model, data

router = APIRouter(
    prefix="/role",
    tags=["role"]
)


@router.get(path="/", response_model=List[model.RoleResponse])
async def role_get():
    res = await data.Role.read_all()
    return res


@router.post(path="/")
async def role_post():
    pass
    return


@router.put(path="/")
async def role_put():
    pass
    return


@router.delete(path="/")
async def role_delete():
    pass
    return
