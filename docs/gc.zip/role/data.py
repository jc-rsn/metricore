from connections.cache import cache


class Role:

    @staticmethod
    async def select(*ids):
        return

    @staticmethod
    async def i