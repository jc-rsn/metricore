from pydantic import BaseModel


class RoleSelectRequestBody(BaseModel):
    filter: str


class RoleSelectResponseBody(BaseModel):
    role_id: int
    role_name: str | None
