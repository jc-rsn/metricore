import psycopg2
from connections.db import const


class Redis:
    connection = redis.Redis(host=const.HOST, port=const.PORT,
                             decode_responses=const.DECODE_RESPONSE)

    def __init__(self):
        self.connection.ping()

    @staticmethod
    def open():
        return redis.Redis(host=const.HOST, port=const.PORT,
                           decode_responses=const.DECODE_RESPONSE)
