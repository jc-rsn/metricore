from connections.cache.connect import pool

cache = pool.get_connection()
