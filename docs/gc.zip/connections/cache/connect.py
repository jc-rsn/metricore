import redis
from connections.cache import conf

__all__ = ['cache']


class Cache:
    def __init__(self):
        self.next = 0
        self.reserved_next = 0
        self.reserved_pool = [redis.Redis(connection_pool=self.create_pool()) for _ in
                              range(conf.RESERVED_CONNECTION_COUNT)]
        self.pool = [redis.Redis(connection_pool=self.create_pool()) for _ in range(conf.CONNECTION_COUNT)]

    def __exit__(self):
        for client in self.pool:
            client.close()

    @staticmethod
    def create_pool():
        return redis.ConnectionPool(host=conf.HOST, port=conf.PORT, db=conf.DB_ID,
                                    max_connections=conf.CONNECTION_COUNT,
                                    decode_responses=conf.DECODE_RESPONSE)

    def get_connection(self, connection_type: str = None):
        if connection_type is None:
            connection = self.pool[self.next]
            self.next = (self.next + 1) % conf.CONNECTION_COUNT
        elif type == 'reserved':
            connection = self.reserved_pool[self.reserved_next]
            self.reserved_next = (self.reserved_next + 1) % conf.RESERVED_CONNECTION_COUNT
        return connection


pool = Cache()
cache = pool.get_connection()
