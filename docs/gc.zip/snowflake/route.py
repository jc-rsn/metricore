from fastapi import APIRouter
from snowflake import model, data

router = APIRouter(
    prefix="/snowflake",
    tags=["snowflake"]
)


@router.get(path="/", response_model=model.Snowflake)
async def create():
    return data.Snowflake.create()
