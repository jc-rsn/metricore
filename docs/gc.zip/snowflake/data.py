import datetime
from datetime import timezone
from snowflake import const, var


class Snowflake:

    @staticmethod
    def create():
        timestamp = int(datetime.datetime.now(timezone.utc).replace(
            tzinfo=timezone.utc).timestamp() * 1000) - const.EPOCH_START

        if timestamp < 0:
            raise Exception("Error: Check Snowflake Epoch Start")

        if timestamp == var.LAST_TIMESTAMP:
            var.SAME_MILLISECOND_SEQUENCE += 1
        else:
            var.SNOWFLAKE_LAST_TIMESTAMP = timestamp
            var.SNOWFLAKE_SAME_MILLISECOND_SEQUENCE = 0

        snowflake = {"timestamp": [int(c) for c in format(timestamp, 'b')],
                     "node": [int(c) for c in format(const.NODE_ID, 'b')],
                     "sequence": [int(c) for c in format(var.SAME_MILLISECOND_SEQUENCE, 'b')],
                     }

        snowflake_bit_arr = []

        for block in snowflake:
            block_actual_length = len(snowflake[block])
            block_required_length = len(const.TEMPLATE[block])
            block_offset = block_required_length - block_actual_length
            for i in range(block_required_length):
                if i < block_offset:
                    snowflake_bit_arr.append(const.TEMPLATE[block][i])
                else:
                    snowflake_bit_arr.append(
                        const.TEMPLATE[block][i] + snowflake[block][i - block_offset])

        snowflake_bitstring = ''.join(str(bit) for bit in snowflake_bit_arr)

        snowflake_id = int(snowflake_bitstring, 2)

        return {"snowflake_id": snowflake_id}
