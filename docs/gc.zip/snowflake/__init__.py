from random import randint
from snowflake import const, var
from connections.cache import cache


class SystemInit:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        var.LAST_TIMESTAMP = const.EPOCH_START
        const.NODE_ID = randint(1, 1000000000) % 1024
        return


init = SystemInit()
