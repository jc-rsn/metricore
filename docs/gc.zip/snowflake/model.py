from pydantic import BaseModel


class Snowflake(BaseModel):
    snowflake_id: int
