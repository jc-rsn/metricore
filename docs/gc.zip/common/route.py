from fastapi import APIRouter
from common import data, model

router = APIRouter(tags=["common"])


@router.get(path="/login", response_model=model.LoginResponseBody)
async def login_get():
    response = data.login_get()
    return response


@router.get(path="/version", response_model=model.VersionResponseBody)
async def version():
    response = data.version_get()
    return response


@router.get(path="/health", response_model=model.HealthResponseBody)
async def health():
    response = data.health_get()
    return response
