from common import const


def login_get():
    return {"message": "message",
            "expireAt": 0,
            "token": "token"}


def version_get():
    return {"version": const.VERSION_NUMBER,
            "date": const.VERSION_DATE}


def health_get():
    return {"status": const.HEALTH_MESSAGE}
