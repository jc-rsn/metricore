from pydantic import BaseModel


class LoginRequestBody(BaseModel):
    username: str
    password: str
    timestamp: int
    timezone: int


class LoginResponseBody(BaseModel):
    message: str
    expireAt: int
    token: str


class VersionRequestBody(BaseModel):
    pass


class VersionResponseBody(BaseModel):
    version: str
    date: str


class HealthRequestBody(BaseModel):
    pass


class HealthResponseBody(BaseModel):
    status: str
